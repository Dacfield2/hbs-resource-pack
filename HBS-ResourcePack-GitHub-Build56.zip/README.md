# HBS Resource Pack

Publiez le fichier `hbs-ultimate-resource-pack.zip` à la racine de ce dépôt.

CDN utilisé par HBS Ultimate Build56+ :
`https://cdn.jsdelivr.net/gh/Dacfield2/hbs-resource-pack@main/hbs-ultimate-resource-pack.zip`

Ne renommez pas le ZIP sans modifier la configuration HBS.
